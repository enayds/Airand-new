# Airand pilot dataset — [SIMULATED]

Synthetic data for the Airand Business Analysis case study. **Nothing here is real**: vendors, cyclists, phone numbers and addresses are invented; receiver phones are stored as `enc:SIMULATED`.

- Period: 90 operating days, 6 Jul – 3 Oct 2026, Zone 1 (World Bank Road, New Owerri)
- Schema: matches *Airand — Data Model & Data Dictionary* (12 tables)
- Timestamps: UTC in storage (`...Z`); add 1 hour for West Africa Time
- Reproducible: `python3 generate_airand_simulated.py` (seed 20261006) rebuilds identical files

## Files
| File | What it is |
|---|---|
| `airand_SIMULATED.sqlite` | All 12 tables in one SQLite database (open with DB Browser for SQLite, DBeaver, or Python) |
| `csv_SIMULATED/*.csv` | The same tables as CSV, for Power BI / Excel / Tableau |
| `generate_airand_simulated.py` | The generator, with every assumption in code |

## Row counts
zone 1 · admin_user 2 · vendor 8 · wallet 8 · cyclist 10 · shift 772 · delivery 4,932 · delivery_event 50,132 · payment 4,932 · wallet_transaction 5,034 · alert 2,063 · statement 85

## Assumptions built into the simulation
- **Vendors:** 8, joining between day 0 and day 38; two anchors (Suya Republic, Grillz & Pepper Soup). Each new vendor gets a 7-day free trial (fee ₦0).
- **Demand:** ramps from ~55% to ~95% of each vendor's base over 70 days; Fri ×1.3, Sat ×1.25, Sun ×0.9; 12:00–23:30 with ~60% of requests after 18:00.
- **Roster:** 10 cyclists, each off one weekday (never Fri/Sat); 3 on 12:00–20:00, 7 on 15:30–23:30.
- **Timings (medians):** accept 4–35 s · hub to vendor 4 min · vendor handover 1.5–3.2 min by vendor · ride 10 min (×1.25 on 14 rain days, +12–26 min on ~4% of trips) · return 3.5 min.
- **Exceptions:** 1.8% payment expiry · 1.5% cancelled before assignment · 1.5% after assignment · 0.4% refused at pickup · 2.8% failed at the door · 2.2% delivered without code · 2.5–8% of offers time out per cyclist.
- **Vendor delays:** each vendor has a propensity (Grillz & Pepper Soup highest at 22%).

## What the data shows (headline, for orientation)
- Settled deliveries per day: July ≈ 29 · August ≈ 54 · September ≈ 68 · early October ≈ 81
- The 7-day average first reaches break-even (≈ 46/day) on **2 Aug 2026**
- Queues are concentrated **before 15:30 and after 20:00**, when only one shift is on — the roster shape, not the headcount, is the constraint

## SQL and Tableau-ready tables (Phase 8)
| File | What it is |
|---|---|
| `sql/01_params_and_views.sql` | Cost parameters + four analysis views: `v_delivery`, `v_zone_day`, `v_cyclist_shift`, `v_vendor_week` |
| `sql/02_kpi_queries.sql` | K01–K23, one query each, monthly grain, following the KPI Definitions counting rules |
| `run_sql.py` | Builds the views, exports them as CSV and runs every KPI query |
| `tableau_SIMULATED/fact_delivery_SIMULATED.csv` | One row per request, durations pre-computed, WAT times — Operations page |
| `tableau_SIMULATED/zone_day_SIMULATED.csv` | One row per day: volumes, revenue, costs, profit, break-even — Viability page |
| `tableau_SIMULATED/cyclist_shift_SIMULATED.csv` | One row per shift: busy time, utilisation, pay, missed offers — Cyclists page |
| `tableau_SIMULATED/vendor_week_SIMULATED.csv` | One row per vendor per week — Vendors page |
| `tableau_SIMULATED/kpi_results_by_month_SIMULATED.csv` | Every KPI value by month, long format |

Note: July starts on the 6th and October covers only 1–3 Oct; treat both as partial months.
